<?php

return [
    'unset_country' => 'Your country is not set.',
    'unavailable_country' => 'Your country is not available',
    'account_limit' => 'You cannot add anymore accounts.',
    'transfer_description' => '(Bank Transfer) :number - :bank',
];
